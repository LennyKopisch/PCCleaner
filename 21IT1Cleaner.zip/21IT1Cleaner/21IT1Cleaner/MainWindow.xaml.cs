﻿using System;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PcCleaner
{
    public partial class MainWindow : Window
    {
        public DirectoryInfo winTemp;
        public DirectoryInfo appTemp;

        public MainWindow()
        {
            InitializeComponent();
            winTemp = new DirectoryInfo(@"C:\Windows\Temp");
            appTemp = new DirectoryInfo(System.IO.Path.GetTempPath());
        }

        // Funktion zur Berechnung der Größe eines Verzeichnisses
        public long DirSize(DirectoryInfo dir)
        {
            long size = 0;
            try
            {
                FileInfo[] files = dir.GetFiles();
                foreach (FileInfo file in files)
                {
                    size += file.Length;
                }
                DirectoryInfo[] dirs = dir.GetDirectories();
                foreach (DirectoryInfo subdir in dirs)
                {
                    size += DirSize(subdir);
                }
            }
            catch (UnauthorizedAccessException)
            {
                // Hierdurch werden Geschützte Dateien und Verzeichnisse ignoriert
            }
            return size;
        }

        private void Button_History_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("TODO: Historienseite erstellen", "Verlauf", MessageBoxButton.OK, MessageBoxImage.Information);
        }


        private void Button_Analyse_Click(object sender, RoutedEventArgs e)
        {
            AnalyseFolders();
        }

        // Hier ist die Funktion zur Analyse der Größe der zu löschenden Dateien und Verzeichnisse, dazu noch eine Fehlermeldung falls das Verzeichnis nicht Analysiert werden konnte
        public void AnalyseFolders()
        {
            Console.WriteLine("Analyse beginnt...");
            long totalSize = 0;

            try
            {
                totalSize += DirSize(winTemp) / 1000000;
                totalSize += DirSize(appTemp) / 1000000;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Verzeichnisse konnten nicht analysiert werden: " + ex.Message);
            }


            space.Content = totalSize + " Mb";
            title.Content = "Analyse abgeschlossen!";
            date.Content = DateTime.Today.ToString("dd.MM.yyyy");

        }



        // Hier ist die Funktion zum Leeren eines Verzeichnisses
        public void ClearTempData(DirectoryInfo di)
        {
            foreach (FileInfo file in di.GetFiles())
            {
                try
                {
                    file.Delete();
                    Console.WriteLine(file.FullName);
                }
                catch (Exception ex)
                {
                    continue;
                }
            }

            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                try
                {
                    dir.Delete(true);
                    Console.WriteLine(dir.FullName);
                }
                catch (Exception ex)
                {
                    continue;
                }
            }
        }

        private async void Button_Clean_Click(object sender, RoutedEventArgs e)
        {
            // Hiermit lassen wir das Progress Window anzeigen
            ProgressWindow progressWindow = new ProgressWindow();
            progressWindow.Show();

            try
            {
                // Hiermit lassen wir den Reinigungsprozess starten
                await Task.Run(() =>
                {
                    ClearTempData(winTemp);
                    ClearTempData(appTemp);
                });

                // Hier wird angezeigt das die Reinigung erfolgreich beendet wurde, und wie viel bereinigt und freigegeben wurde
                progressWindow.SetProgressMessage("Reinigung abgeschlossen!");
                btnClean.Content = "Reinigung fertig!";
                title.Content = "Reinigung abgeschlossen!";
                space.Content = "0 MB";
            }
            catch (Exception ex)
            {
                // Hier wird die Fehlermeldung und die Dazugehörige Nachricht ausgegeben
                progressWindow.SetProgressMessage("Fehler bei der Reinigung: " + ex.Message);
            }
            finally
            {
                // Hiermit alassen wir das Progress Window schließen
                progressWindow.Close();
            }
        }

        private async void Button_Optimize_Click(object sender, RoutedEventArgs e)
        {
            ProgressWindow progressWindow = new ProgressWindow();
            progressWindow.Show();

            try
            {
                await Task.Run(() =>
                {
                    // Hiermit Deaktivieren wir die Windows Game Bar
                    DisableWindowsGameBar();

                    // Hiermit werden Xbox Programme beendet
                    TerminateXboxProcesses();

                    

                    // Führe weitere Optimierungen durch...
                });

                progressWindow.SetProgressMessage("Optimierung abgeschlossen!");
                MessageBox.Show("GameBar und XBOX Bloatware deaktiviert.", "21IT1Cleaner", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                progressWindow.SetProgressMessage("Fehler bei der Optimierung: " + ex.Message);
            }
            finally
            {
                progressWindow.Close();
            }
        }

        private void DisableWindowsGameBar()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Service WHERE Name='XblAuthManager'"))
                {
                    foreach (ManagementObject service in searcher.Get())
                    {
                        string serviceName = service["Name"].ToString();
                        // Hierdurch wird der Dienst gestoppt, falls er ausgeführt wird
                        ServiceController controller = new ServiceController(serviceName);
                        if (controller.Status == ServiceControllerStatus.Running)
                        {
                            controller.Stop();
                            controller.WaitForStatus(ServiceControllerStatus.Stopped);
                        }
                        // Hierdurch wird der Starttyp des Dienstes auf Manuell umgeändert
                        using (ManagementObject serviceConfig = new ManagementObject(new ManagementPath($"Win32_Service.Name='{serviceName}'")))
                        {
                            object[] parameters = new object[1];
                            parameters[0] = "Manual";
                            serviceConfig.InvokeMethod("ChangeStartMode", parameters);
                        }
                        // Hierdurch wird der Dienst nicht automatisch neu gestarter, da wir ihn deaktivieren möchten
                    }
                }
            }

            catch (Exception ex)
            {
                throw new Exception("Fehler beim Deaktivieren der Windows Game Bar: " + ex.Message);
            }
        }


        private void TerminateXboxProcesses()
        {
            try
            {
                Process[] processes = Process.GetProcessesByName("XboxApp.exe");
                foreach (Process process in processes)
                {
                    process.Kill();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Fehler beim Beenden von Xbox-Prozessen: " + ex.Message);
            }
        }




    }
}
