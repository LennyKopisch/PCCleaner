﻿using System.Windows;

namespace PcCleaner
{
    public partial class ProgressWindow : Window
    {
        public ProgressWindow()
        {
            InitializeComponent();
        }

        public void SetProgressMessage(string message)
        {
            // Hiermit wird eine Fortschrittsnachricht gesetzt
            progressLabel.Content = message;
        }
    }
}
